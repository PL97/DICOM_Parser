from .dicom_parser import batch_extraction

__version__ = "0.1.0"
__author__ = "Le Peng"
